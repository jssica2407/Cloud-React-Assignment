import React, { useEffect, useState } from 'react'
import { geocodeCity, getCurrentWeather } from '../services/weather.js'

export default function WeatherWidget({ defaultCity = 'Taipei' }){
  const [city, setCity] = useState(defaultCity)
  const [resolved, setResolved] = useState(null)
  const [weather, setWeather] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function load(c){
    try{
      setError(''); setLoading(true)
      const loc = await geocodeCity(c)
      setResolved(loc)
      const w = await getCurrentWeather(loc)
      setWeather(w)
    }catch(e){
      setError(e.message || 'Terjadi kesalahan')
    }finally{
      setLoading(false)
    }
  }

  useEffect(()=>{ load(city) }, [])
  const onSubmit = (e)=>{ e.preventDefault(); load(city) }

  return (
    <div>
      <form onSubmit={onSubmit} style={{display:'flex', gap:8, marginBottom:12}}>
        <input className="input" value={city} onChange={e=>setCity(e.target.value)} placeholder="Nama kota (mis. Taipei)" />
        <button className="button" type="submit">Cari</button>
      </form>

      {loading && <p>Memuat...</p>}
      {error && <p style={{color:'#ff9b9b'}}>Error: {error}</p>}

      {resolved && weather && !loading && !error && (
        <div className="kv">
          <div>Kota</div><div>{resolved.label}</div>
          <div>Suhu</div><div>{weather.temperature} °C</div>
          <div>Kecepatan Angin</div><div>{weather.windspeed} km/h</div>
          <div>Arah Angin</div><div>{weather.winddirection}°</div>
          <div>Waktu</div><div>{new Date(weather.time).toLocaleString()}</div>
        </div>
      )}
    </div>
  )
}
