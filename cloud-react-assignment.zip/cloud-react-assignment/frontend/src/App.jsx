import React from 'react'
import WeatherWidget from './components/WeatherWidget.jsx'

export default function App(){
  return (
    <div className="container">
      <div className="card" style={{marginBottom:16}}>
        <h1 className="h1">React + REST API + Cloud (Demo)</h1>
        <p>Contoh sederhana: frontend React memanggil REST API pihak ketiga (Open-Meteo).</p>
        <small className="muted">Bonus: siap di-build & deploy ke S3 + CloudFront via CI/CD.</small>
      </div>

      <div className="row">
        <div className="card" style={{flex:1,minWidth:300}}>
          <h2 className="h2">Cuaca Kota</h2>
          <WeatherWidget defaultCity="Taipei" />
        </div>
      </div>
    </div>
  )
}
