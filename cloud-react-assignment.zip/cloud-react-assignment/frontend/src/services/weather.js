const BASE_GEOCODE = 'https://geocoding-api.open-meteo.com/v1/search'
const BASE_WEATHER = 'https://api.open-meteo.com/v1/forecast'

export async function geocodeCity(name){
  const url = `${BASE_GEOCODE}?name=${encodeURIComponent(name)}&count=1&language=en&format=json`
  const res = await fetch(url)
  if(!res.ok) throw new Error('Gagal memanggil geocoding API')
  const data = await res.json()
  if(!data.results || data.results.length === 0) throw new Error('Kota tidak ditemukan')
  const { latitude, longitude, name: resolvedName, country } = data.results[0]
  return { latitude, longitude, label: `${resolvedName}, ${country}` }
}

export async function getCurrentWeather({ latitude, longitude }){
  const params = new URLSearchParams({
    latitude: latitude.toString(),
    longitude: longitude.toString(),
    current_weather: 'true',
    hourly: 'temperature_2m'
  })
  const url = `${BASE_WEATHER}?${params.toString()}`
  const res = await fetch(url)
  if(!res.ok) throw new Error('Gagal memanggil weather API')
  const data = await res.json()
  return data.current_weather
}
