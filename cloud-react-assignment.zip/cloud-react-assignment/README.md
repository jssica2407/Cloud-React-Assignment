# Cloud Frontend Assignment — React + API + CI/CD + IaC (AWS)

Dokumen ini memandu kamu **end-to-end** untuk menyelesaikan seluruh tugas:
1) React frontend + integrasi REST API,
2) Diagram arsitektur cloud,
3) Diagram alur CI/CD,
4) IaC (Terraform) untuk hosting statis di **AWS S3 + CloudFront**,
5) Workflow GitHub Actions untuk deploy.

> Kamu bisa memulai dari bagian **A** lalu lanjut **B → C → D**. Semua contoh sudah disiapkan.

---

## A. Menjalankan Frontend React (lokal)

### Prasyarat
- Node.js ≥ 18 dan npm
- Git & akun GitHub
- Akun AWS (untuk bagian D)

### Langkah
```bash
# 1) install dependencies
cd frontend
npm install

# 2) jalankan lokal
npm run dev

# 3) build produksi
npm run build
```

> Proyek ini menggunakan **Vite**. Jika kamu ingin membuat ulang dari nol:
> ```bash
> npm create vite@latest myapp -- --template react
> cd myapp && npm install
> ```
> Lalu copy berkas di folder `frontend/src` ke proyekmu.

### Fitur yang ada
- Komponen **WeatherWidget** yang memanggil REST API **Open-Meteo** (tanpa API key) untuk menampilkan cuaca kota (contoh: Taipei).
- Kode modul dipisah di `src/services/weather.js` agar rapi.

---

## B. Diagram Arsitektur & CI/CD

File diagram dalam format **Mermaid** ada di folder `diagrams/`:
- `cloud-architecture.mmd` — arsitektur CloudFront + S3 + API pihak ketiga.
- `cicd-pipeline.mmd` — alur CI/CD GitHub Actions → S3 → CloudFront.

Cara melihat:
1. Buka https://mermaid.live
2. Paste isi file `.mmd` untuk merender sebagai diagram.
3. Export sebagai **PNG/SVG** untuk dikirim ke perusahaan.

---

## C. CI/CD dengan GitHub Actions

Workflow berada di `.github/workflows/deploy.yml` dan akan:
1. Checkout kode, install dependency, **build** React.
2. **Sync** folder `dist/` ke S3.
3. **Invalidate** CloudFront agar versi baru langsung aktif.

### Konfigurasi Rahasia & Variabel Repo
Di GitHub repo → **Settings → Secrets and variables**:
- **Secrets**:
  - `AWS_ACCESS_KEY_ID`
  - `AWS_SECRET_ACCESS_KEY`
  - `AWS_REGION` (mis. `ap-southeast-1`)
- **Variables**:
  - `S3_BUCKET` — nama bucket S3 tempat hosting
  - `CF_DISTRIBUTION_ID` — ID CloudFront

> Buat IAM user khusus **deploy-frontend** dengan izin minimal (lihat `docs/iam-policy-github-actions.json`).

---

## D. Infrastructure as Code (Terraform)

### Apa yang dibuat
- 1 bucket **S3** (private) untuk file statis
- 1 **Origin Access Control (OAC)** agar CloudFront bisa baca S3
- 1 **CloudFront Distribution** (HTTPS, kompresi, SPA fallback ke `index.html`)

### Langkah menjalankan
```bash
cd iac/terraform

# set nilai variabel (contoh)
export TF_VAR_bucket_name="my-react-frontend-bucket-12345"
export TF_VAR_aws_region="ap-southeast-1"
export TF_VAR_project_name="react-cloud-frontend"

# auth AWS (via environment atau AWS profile)
# lalu:
terraform init
terraform validate
terraform plan
terraform apply
```

Output akan menampilkan `cloudfront_domain_name`. Setelah selesai deploy, akses aplikasi melalui domain tersebut.

> **Catatan SPA**: Error 403/404 diarahkan ke `index.html` dari CloudFront agar routing React tetap bekerja.

---

## E. Struktur Folder

```
cloud-react-assignment/
├─ frontend/                # Kode React + Vite
│  ├─ public/
│  └─ src/
│     ├─ components/        # UI components
│     ├─ services/          # API helpers
│     ├─ App.jsx
│     └─ main.jsx
├─ diagrams/                # Mermaid diagram files
├─ iac/
│  └─ terraform/            # Terraform untuk S3 + CloudFront
├─ .github/workflows/       # GitHub Actions workflow
└─ docs/                    # Dokumen tambahan (IAM policy, dsb)
```

---

## F. Checklist Penyerahan

- [ ] **Link Git** ke repo berisi: `frontend`, `diagrams`, `iac`, `.github/workflows`
- [ ] **Diagram arsitektur** (PNG/SVG export dari Mermaid)
- [ ] **Diagram CI/CD** (PNG/SVG export dari Mermaid)
- [ ] (Bonus) Screenshot halaman React menampilkan data cuaca
- [ ] (Bonus) Terraform output (CloudFront domain) atau hasil `terraform plan`

Semoga membantu! Lihat setiap berkas untuk penjelasan lebih lanjut. 🚀
